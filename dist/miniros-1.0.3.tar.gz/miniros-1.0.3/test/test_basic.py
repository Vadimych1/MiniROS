import pytest
import asyncio
from miniros import AsyncROSClient
from miniros.base.server import run


@pytest.mark.asyncio
async def test_server_running():
    server = run(
        ip="localhost",
        port=3000,
    )

    client = AsyncROSClient(
        "test-client",
        ip="localhost",
        port=3000,
    )

    async def _test():
        await client.wait()

    done, pending = await asyncio.wait(
        [asyncio.gather(server, client.run(), _test())], timeout=2
    )

    print(done, pending)
